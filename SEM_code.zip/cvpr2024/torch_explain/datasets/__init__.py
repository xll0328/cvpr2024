from .benchmarks import xor, trigonometry, dot

__all__ = [
    'xor',
    'trigonometry',
    'dot',
]
