Authors
=======

* `Pietro Barbiero <http://www.pietrobarbiero.eu/>`__, University of Cambridge, UK.
* Mateo Espinosa Zarlenga, University of Cambridge, UK.
* Giuseppe Marra, Katholieke Universiteit Leuven, BE.
* Steve Azzolin, University of Trento, IT.
* Francesco Giannini, University of Florence, IT.
* Gabriele Ciravegna, University of Florence, IT.
* Dobrik Georgiev, University of Cambridge, UK.
