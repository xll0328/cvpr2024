Logic explanations for :math:`\psi` LENs
==============================================

:mod:`torch_explain.logic.nn.psi`

.. automodule:: torch_explain.logic.nn.psi
    :members: