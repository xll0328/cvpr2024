Logic explanations for entropy-based LENs
==============================================

:mod:`torch_explain.logic.nn.entropy`

.. automodule:: torch_explain.logic.nn.entropy
    :members: