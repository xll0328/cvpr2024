Logic layers
==============================================

:mod:`torch_explain.nn.logic`

.. automodule:: torch_explain.nn.logic
    :members: