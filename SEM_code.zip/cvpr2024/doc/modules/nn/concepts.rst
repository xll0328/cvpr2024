APIs for concepts
==============================================

:mod:`torch_explain.nn.concepts`

.. automodule:: torch_explain.nn.concepts
    :members: