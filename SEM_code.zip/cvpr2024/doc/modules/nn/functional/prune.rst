Prune functions to simplify the neural model
==============================================

:mod:`torch_explain.nn.functional.prune`

.. automodule:: torch_explain.nn.functional.prune
    :members: