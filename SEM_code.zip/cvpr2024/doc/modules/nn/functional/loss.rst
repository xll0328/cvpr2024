Loss functions to regularize the neural model
==============================================

:mod:`torch_explain.nn.functional.loss`

.. automodule:: torch_explain.nn.functional.loss
    :members: